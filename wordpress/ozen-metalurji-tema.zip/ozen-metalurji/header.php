<?php
/** Özen Metalurji — üst kısım */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class( ozen_body_class() ); ?>>
<?php wp_body_open(); ?>
<?php echo ozen_partial( 'header' ); // phpcs:ignore ?>
<main id="icerik">
